"""Competition harness components."""
